# Zenith X Nexus

Aplikasi performa Android tanpa root. Pantau kondisi HP, atur boost options per game, cek jaringan, dan rapikan file sampah.

## Menu
- Beranda: system health (CPU, RAM, penyimpanan, baterai), dan booster yang otomatis aktif saat game dibuka
- Game: pilih game, atur boost options, lalu main
- Alat: cek jaringan, benchmark, app analyzer, process manager, bersih-bersih, layar dan Hz, advanced (baca saja), status koneksi
- Lainnya: riwayat, statistik, pengingat istirahat, cadangan pengaturan, panduan, dan tentang

## Batasan
- Tidak mengubah kernel. Nilai di menu advanced hanya dibaca.
- Hz dan animasi sistem butuh WRITE_SECURE_SETTINGS, yang diberikan sekali lewat ADB atau Shizuku.
- Tidak menjamin FPS naik.
