package com.zenith.nexus

import android.Manifest
import android.app.AppOpsManager
import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.Display

data class AppInfo(val pkg: String, val label: String)

data class WifiStat(val rssi: Int, val linkMbps: Int)

object Device {

    fun hasUsageAccess(c: Context): Boolean {
        val appOps = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasDndAccess(c: Context): Boolean =
        c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun canWriteSettings(c: Context): Boolean = Settings.System.canWrite(c)

    fun hasWriteSecure(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    fun isDeviceSecure(c: Context): Boolean =
        c.getSystemService(KeyguardManager::class.java).isDeviceSecure

    /** Suhu baterai dalam derajat Celsius. Mengembalikan 0 jika tidak terbaca. */
    fun batteryTempC(c: Context): Double {
        val intent = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 0.0
        return intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
    }

    /** Semua app yang punya ikon peluncur, kecuali booster ini. */
    fun launchableApps(c: Context): List<AppInfo> {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun isInstalled(c: Context, pkg: String): Boolean {
        return try {
            c.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun labelOf(c: Context, pkg: String): String {
        val pm = c.packageManager
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            pkg
        }
    }

    /** Ukuran cache sebuah app. Butuh izin akses penggunaan. Mengembalikan -1 jika gagal. */
    fun cacheBytes(c: Context, pkg: String): Long {
        return try {
            val ssm = c.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
            ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, Process.myUserHandle()).cacheBytes
        } catch (e: Exception) {
            -1L
        }
    }

    /** Info WiFi yang tersambung. Null jika tidak tersambung ke WiFi. */
    fun wifi(c: Context): WifiStat? {
        val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val info = wm.connectionInfo
        return if (info == null || info.rssi <= -127) null else WifiStat(info.rssi, info.linkSpeed)
    }

    fun networkType(c: Context): String {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork ?: return "tidak ada koneksi"
        val caps = cm.getNetworkCapabilities(net) ?: return "tidak ada koneksi"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "data seluler"
            else -> "lainnya"
        }
    }

    private fun display(c: Context): Display =
        c.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)

    fun currentRefresh(c: Context): Float = display(c).refreshRate

    fun refreshRates(c: Context): List<Float> =
        display(c).supportedModes.map { it.refreshRate }.distinct().sorted()
}
