package com.zenith.nexus

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityAdvancedBinding
import java.io.File

class AdvancedActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdvancedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdvancedBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.advStatus.text = getString(R.string.adv_hint)

        binding.btnAnimOn.setOnClickListener {
            val ok = AnimTuner.apply(this)
            Toast.makeText(this, if (ok) "Animasi dipercepat" else "Izin belum ada", Toast.LENGTH_SHORT).show()
            render()
        }
        binding.btnAnimOff.setOnClickListener {
            val ok = AnimTuner.restore(this)
            Toast.makeText(this, if (ok) "Animasi dikembalikan" else "Gagal mengembalikan", Toast.LENGTH_SHORT).show()
            render()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        binding.govValue.text = readFile("/sys/devices/system/cpu/cpufreq/policy0/scaling_governor")
        val min = readFile("/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq")
        val max = readFile("/sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq")
        binding.freqValue.text = "$min - $max kHz"
        val dirty = readFile("/proc/sys/vm/dirty_ratio")
        val swappiness = readFile("/proc/sys/vm/swappiness")
        binding.vmValue.text = "dirty_ratio: $dirty, swappiness: $swappiness"
        binding.animValue.text = getString(
            if (Device.hasWriteSecure(this)) R.string.adv_perm_ok else R.string.adv_need_perm
        )
    }

    private fun readFile(path: String): String {
        return try {
            File(path).readText().trim().ifEmpty { "kosong" }
        } catch (e: Exception) {
            "tidak terbaca"
        }
    }
}
