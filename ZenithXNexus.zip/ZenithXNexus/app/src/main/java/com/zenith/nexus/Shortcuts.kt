package com.zenith.nexus

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/** Shortcut di ikon app: tahan ikon untuk langsung main game favorit. */
object Shortcuts {

    fun update(c: Context) {
        val gameShortcuts = Prefs.games(c)
            .filter { Device.isInstalled(c, it) }
            .sortedBy { Device.labelOf(c, it) }
            .take(3)
            .map { pkg ->
                val label = Device.labelOf(c, pkg)
                ShortcutInfoCompat.Builder(c, "game_$pkg")
                    .setShortLabel("Main $label")
                    .setLongLabel("Main $label dengan booster")
                    .setIcon(IconCompat.createWithResource(c, R.mipmap.ic_launcher))
                    .setIntent(
                        Intent(c, MainActivity::class.java)
                            .setAction(Intent.ACTION_VIEW)
                            .putExtra("launch", pkg)
                    )
                    .build()
            }

        val networkShortcut = ShortcutInfoCompat.Builder(c, "tool_network")
            .setShortLabel("Cek jaringan")
            .setLongLabel("Cek ping dan tes speed")
            .setIcon(IconCompat.createWithResource(c, R.mipmap.ic_launcher))
            .setIntent(
                Intent(c, NetworkActivity::class.java).setAction(Intent.ACTION_VIEW)
            )
            .build()

        ShortcutManagerCompat.setDynamicShortcuts(c, gameShortcuts + networkShortcut)
    }
}
