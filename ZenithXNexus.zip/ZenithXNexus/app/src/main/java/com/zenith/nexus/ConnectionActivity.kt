package com.zenith.nexus

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityConnectionBinding

class ConnectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConnectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConnectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val shizuku = if (Device.isInstalled(this, SHIZUKU_PKG)) "terpasang" else "belum terpasang"
        val rows = listOf(
            "Shizuku" to shizuku,
            "izin pengaturan aman" to yesNo(Device.hasWriteSecure(this)),
            "akses penggunaan" to yesNo(Device.hasUsageAccess(this)),
            "jangan ganggu" to yesNo(Device.hasDndAccess(this)),
            "ubah pengaturan sistem" to yesNo(Device.canWriteSettings(this)),
            "jenis koneksi" to Device.networkType(this)
        )
        binding.connList.removeAllViews()
        rows.forEach { (name, state) ->
            val item = layoutInflater.inflate(R.layout.item_session, binding.connList, false)
            item.findViewById<TextView>(R.id.sessionName).text = name
            item.findViewById<TextView>(R.id.sessionDetail).text = state
            binding.connList.addView(item)
        }
    }

    private fun yesNo(ok: Boolean): String = if (ok) "sudah diizinkan" else "belum"

    companion object {
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }
}
