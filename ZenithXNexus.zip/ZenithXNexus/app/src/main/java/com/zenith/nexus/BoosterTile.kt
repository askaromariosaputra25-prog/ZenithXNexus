package com.zenith.nexus

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Tile di panel Quick Settings: nyalakan atau matikan booster tanpa membuka app. */
class BoosterTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        if (Prefs.isBoosted(this)) {
            stopService(Intent(this, BoostService::class.java))
        } else if (Device.hasUsageAccess(this)) {
            ContextCompat.startForegroundService(this, Intent(this, BoostService::class.java))
        } else {
            Toast.makeText(this, "Izinkan pemakaian data dulu di aplikasi", Toast.LENGTH_SHORT).show()
        }
        Handler(Looper.getMainLooper()).postDelayed({ refreshTile() }, 800L)
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        tile.state = if (Prefs.isBoosted(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.tile_label)
        tile.updateTile()
    }
}
