package com.zenith.nexus

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat

/** Widget di layar home: status booster dan tombol mulai atau matikan. */
class BoosterWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            if (Prefs.isBoosted(context)) {
                context.stopService(Intent(context, BoostService::class.java))
            } else if (Device.hasUsageAccess(context)) {
                ContextCompat.startForegroundService(context, Intent(context, BoostService::class.java))
            }
            refreshAll(context)
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.zenith.nexus.WIDGET_TOGGLE"

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, BoosterWidget::class.java))
            ids.forEach { update(context, manager, it) }
        }

        private fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val boosted = Prefs.isBoosted(context)
            val game = Prefs.currentGame(context)?.let { Device.labelOf(context, it) } ?: "tidak ada game"

            val views = RemoteViews(context.packageName, R.layout.widget_booster)
            views.setTextViewText(R.id.widgetStatus, if (boosted) "booster aktif" else "booster siap")
            views.setTextViewText(R.id.widgetGame, game)
            views.setTextViewText(
                R.id.widgetAction,
                context.getString(if (boosted) R.string.widget_on else R.string.widget_off)
            )

            val toggle = PendingIntent.getBroadcast(
                context,
                10,
                Intent(context, BoosterWidget::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetAction, toggle)

            val open = PendingIntent.getActivity(
                context,
                11,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, open)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
