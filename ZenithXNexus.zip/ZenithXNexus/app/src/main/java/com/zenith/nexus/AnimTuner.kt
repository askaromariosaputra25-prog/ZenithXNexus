package com.zenith.nexus

import android.content.Context
import android.provider.Settings

/** Mempercepat animasi sistem lewat Settings.Global. Hanya jalan kalau WRITE_SECURE_SETTINGS sudah diberikan. */
object AnimTuner {

    private val KEYS = listOf("animator_duration_scale", "window_animation_scale", "transition_animation_scale")

    fun apply(c: Context): Boolean {
        if (!Device.hasWriteSecure(c)) return false
        val cr = c.contentResolver
        if (!Prefs.hasAnimSnap(c)) {
            Prefs.saveAnimSnap(c, KEYS.map { Settings.Global.getFloat(cr, it, 1f) })
        }
        return try {
            KEYS.forEach { Settings.Global.putFloat(cr, it, 0.5f) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun restore(c: Context): Boolean {
        val snap = Prefs.animSnap(c) ?: return true
        if (!Device.hasWriteSecure(c)) return false
        val cr = c.contentResolver
        return try {
            KEYS.zip(snap).forEach { (key, value) -> Settings.Global.putFloat(cr, key, value) }
            Prefs.clearAnimSnap(c)
            true
        } catch (e: Exception) {
            false
        }
    }
}
