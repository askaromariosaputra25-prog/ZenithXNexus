package com.zenith.nexus

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.zenith.nexus.databinding.FragmentToolsBinding

class ToolsFragment : Fragment() {

    private var _b: FragmentToolsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentToolsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.toolNetwork.setOnClickListener { open(NetworkActivity::class.java) }
        b.toolBench.setOnClickListener { open(BenchmarkActivity::class.java) }
        b.toolAnalyzer.setOnClickListener { open(AppAnalyzerActivity::class.java) }
        b.toolProcess.setOnClickListener { open(ProcessActivity::class.java) }
        b.toolCleanup.setOnClickListener { open(CleanupActivity::class.java) }
        b.toolDisplay.setOnClickListener { open(DisplayActivity::class.java) }
        b.toolAdvanced.setOnClickListener { open(AdvancedActivity::class.java) }
        b.toolConnection.setOnClickListener { open(ConnectionActivity::class.java) }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private fun open(target: Class<*>) {
        startActivity(Intent(requireContext(), target))
    }
}
