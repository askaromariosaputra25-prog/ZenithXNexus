package com.zenith.nexus

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.io.File

/** Pakai dan total dalam byte. */
data class Mem(val used: Long, val total: Long)

/** Membaca kondisi HP dari sistem. Nilai yang tidak bisa dibaca dikembalikan sebagai null atau -1. */
object SystemInfo {

    private var lastIdle = 0L
    private var lastTotal = 0L

    /** Perkiraan pemakaian CPU sejak pengecekan terakhir, dari /proc/stat. */
    fun cpuPercent(): Int? {
        return try {
            val line = File("/proc/stat").useLines { it.first() }
            val parts = line.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
            val idle = parts[3] + (parts.getOrNull(4) ?: 0L)
            val total = parts.sum()
            val dIdle = idle - lastIdle
            val dTotal = total - lastTotal
            lastIdle = idle
            lastTotal = total
            if (dTotal <= 0L) null else ((1.0 - dIdle.toDouble() / dTotal) * 100).toInt().coerceIn(0, 100)
        } catch (e: Exception) {
            null
        }
    }

    /** Frekuensi tiap core dalam MHz. Kosong jika tidak terbaca. */
    fun coreFreqsMhz(): List<Int> {
        val cpus = File("/sys/devices/system/cpu").listFiles() ?: return emptyList()
        return cpus
            .filter { it.name.matches(Regex("cpu[0-9]+")) }
            .sortedBy { it.name }
            .mapNotNull { cpu ->
                try {
                    (File(cpu, "cpufreq/scaling_cur_freq").readText().trim().toLong() / 1000L).toInt()
                } catch (e: Exception) {
                    null
                }
            }
    }

    fun ram(c: Context): Mem {
        val am = c.getSystemService(ActivityManager::class.java)
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return Mem(info.totalMem - info.availMem, info.totalMem)
    }

    fun storage(): Mem {
        val s = StatFs(Environment.getDataDirectory().path)
        return Mem(s.totalBytes - s.availableBytes, s.totalBytes)
    }

    fun batteryPercent(c: Context): Int {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        return level * 100 / scale
    }
}
