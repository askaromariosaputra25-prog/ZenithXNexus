package com.zenith.nexus

import android.content.Context
import android.provider.Settings

/**
 * Mengubah batas refresh rate lewat Settings.Secure.
 * Hanya berjalan kalau izin WRITE_SECURE_SETTINGS sudah diberikan lewat ADB.
 * Tidak dijamin berjalan di semua HP, terutama ColorOS.
 */
object DisplayTuner {

    private const val PEAK = "peak_refresh_rate"
    private const val MIN = "min_refresh_rate"

    fun apply(c: Context, hz: Int): Boolean {
        if (hz <= 0 || !Device.hasWriteSecure(c)) return false
        val cr = c.contentResolver
        if (!Prefs.hasHzSnap(c)) {
            Prefs.saveHzSnap(
                c,
                Settings.Secure.getString(cr, PEAK) ?: "",
                Settings.Secure.getString(cr, MIN) ?: ""
            )
        }
        return try {
            Settings.Secure.putString(cr, PEAK, hz.toString()) &&
                Settings.Secure.putString(cr, MIN, hz.toString())
        } catch (e: Exception) {
            false
        }
    }

    fun restore(c: Context): Boolean {
        if (!Prefs.hasHzSnap(c)) return true
        if (!Device.hasWriteSecure(c)) return false
        val (peak, min) = Prefs.hzSnap(c)
        val cr = c.contentResolver
        return try {
            Settings.Secure.putString(cr, PEAK, peak.ifEmpty { null })
            Settings.Secure.putString(cr, MIN, min.ifEmpty { null })
            Prefs.clearHzSnap(c)
            true
        } catch (e: Exception) {
            false
        }
    }
}
