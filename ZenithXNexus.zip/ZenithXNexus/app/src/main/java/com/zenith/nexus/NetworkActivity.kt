package com.zenith.nexus

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityNetworkBinding
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NetworkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNetworkBinding
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNetworkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPing.setOnClickListener { runPing() }
        binding.btnSpeed.setOnClickListener { runSpeed() }
        showSignal()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun showSignal() {
        val wifi = Device.wifi(this)
        val text = if (wifi == null) {
            "tidak tersambung ke WiFi"
        } else {
            "${wifi.rssi} dBm, ${quality(wifi.rssi)}, link ${wifi.linkMbps} Mbps"
        }
        binding.signalValue.text = text
        binding.connValue.text = Device.networkType(this)
    }

    private fun quality(rssi: Int): String = when {
        rssi >= -55 -> "sangat bagus"
        rssi >= -67 -> "bagus"
        rssi >= -75 -> "cukup"
        else -> "lemah"
    }

    private fun runPing() {
        binding.pingValue.text = "mengukur..."
        worker.execute {
            val hosts = listOf("1.1.1.1" to 443, "8.8.8.8" to 53, "google.com" to 443)
            val lines = hosts.map { (host, port) ->
                val samples = (1..3).mapNotNull { connectMs(host, port) }
                if (samples.isEmpty()) {
                    "$host  gagal"
                } else {
                    "$host  ${samples.average().roundToInt()} ms (terendah ${samples.minOrNull()} ms)"
                }
            }
            main.post { binding.pingValue.text = lines.joinToString("\n") }
        }
    }

    private fun connectMs(host: String, port: Int): Long? {
        return try {
            val start = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(host, port), 3000) }
            (System.nanoTime() - start) / 1_000_000L
        } catch (e: Exception) {
            null
        }
    }

    private fun runSpeed() {
        binding.speedValue.text = "mengukur..."
        worker.execute {
            val result = try {
                val conn = URL("https://speed.cloudflare.com/__down?bytes=8000000").openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 15000
                val start = System.nanoTime()
                var total = 0L
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        total += n
                    }
                }
                conn.disconnect()
                val secs = (System.nanoTime() - start) / 1_000_000_000.0
                val mbps = total * 8 / secs / 1_000_000.0
                "%.1f Mbps (%d KB dalam %.1f detik)".format(mbps, total / 1024, secs)
            } catch (e: Exception) {
                "gagal: ${e.message ?: "tidak diketahui"}"
            }
            main.post { binding.speedValue.text = result }
        }
    }
}
