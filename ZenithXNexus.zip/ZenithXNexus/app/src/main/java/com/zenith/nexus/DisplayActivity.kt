package com.zenith.nexus

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityDisplayBinding

class DisplayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDisplayBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnHz30.setOnClickListener { setTarget(30) }
        binding.btnHz60.setOnClickListener { setTarget(60) }
        binding.btnHz120.setOnClickListener { setTarget(120) }
        binding.btnHzOff.setOnClickListener { setTarget(0) }
        binding.btnApply.setOnClickListener { applyNow() }
        binding.btnRestore.setOnClickListener { restoreNow() }
        binding.btnCopyCmd.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("perintah", getString(R.string.disp_cmd)))
            Toast.makeText(this, "Perintah disalin", Toast.LENGTH_SHORT).show()
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun setTarget(hz: Int) {
        Prefs.setHzTarget(this, hz)
        render()
    }

    private fun applyNow() {
        val target = Prefs.hzTarget(this)
        if (target == 0) {
            toast("Pilih 30, 60, atau 120 Hz dulu")
            return
        }
        val ok = DisplayTuner.apply(this, target)
        toast(if (ok) "Hz diubah ke $target" else "Izin belum ada, lihat petunjuknya di bawah")
        render()
    }

    private fun restoreNow() {
        val ok = DisplayTuner.restore(this)
        toast(if (ok) "Hz dikembalikan" else "Gagal mengembalikan Hz")
        render()
    }

    private fun render() {
        binding.nowValue.text = "%.0f Hz".format(Device.currentRefresh(this))
        binding.supportedValue.text = Device.refreshRates(this).joinToString(", ") { "%.0f Hz".format(it) }

        val target = Prefs.hzTarget(this)
        binding.targetValue.text = if (target > 0) "$target Hz saat main" else "tidak diubah"

        val granted = Device.hasWriteSecure(this)
        binding.permValue.text = if (granted) getString(R.string.disp_ok) else getString(R.string.disp_perm)
        binding.cmdValue.visibility = if (granted) View.GONE else View.VISIBLE
        binding.btnCopyCmd.visibility = if (granted) View.GONE else View.VISIBLE
        binding.cmdValue.text = getString(R.string.disp_cmd)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
