package com.zenith.nexus

import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.storage.StorageManager
import android.text.format.Formatter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityAppAnalyzerBinding
import java.util.concurrent.Executors

class AppAnalyzerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppAnalyzerBinding
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppAnalyzerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnAnalyze.setOnClickListener { load() }
        load()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun load() {
        binding.analyzeStatus.text = getString(R.string.analyze_loading)
        worker.execute {
            val rows = Device.launchableApps(this).map { app ->
                val perms = try {
                    packageManager.getPackageInfo(app.pkg, PackageManager.GET_PERMISSIONS)
                        .requestedPermissions?.size ?: 0
                } catch (e: Exception) {
                    0
                }
                Triple(app.label, perms, appBytes(app.pkg))
            }
                .sortedByDescending { it.third }
                .take(60)
            main.post { show(rows) }
        }
    }

    private fun appBytes(pkg: String): Long {
        return try {
            val ssm = getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
            ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, Process.myUserHandle()).appBytes
        } catch (e: Exception) {
            -1L
        }
    }

    private fun show(rows: List<Triple<String, Int, Long>>) {
        binding.analyzeList.removeAllViews()
        binding.analyzeStatus.text = if (rows.isEmpty()) {
            getString(R.string.analyze_empty)
        } else {
            getString(R.string.analyze_footer)
        }
        rows.forEach { (label, perms, bytes) ->
            val item = layoutInflater.inflate(R.layout.item_session, binding.analyzeList, false)
            item.findViewById<TextView>(R.id.sessionName).text = label
            val size = if (bytes < 0L) "ukuran tidak terbaca" else Formatter.formatFileSize(this, bytes)
            item.findViewById<TextView>(R.id.sessionDetail).text = "$size · $perms izin"
            binding.analyzeList.addView(item)
        }
    }
}
