package com.zenith.nexus

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.zenith.nexus.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val main = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            refresh()
            main.postDelayed(this, 2000L)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val act = requireActivity() as MainActivity

        b.btnToggle.setOnClickListener {
            if (Prefs.isBoosted(requireContext())) act.stopBooster() else act.startBooster()
        }
        b.timerOff.setOnClickListener { setTimer(0) }
        b.timer30.setOnClickListener { setTimer(30) }
        b.timer60.setOnClickListener { setTimer(60) }
        b.timer120.setOnClickListener { setTimer(120) }

        b.btnUsage.setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        b.btnDnd.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        b.btnWrite.setOnClickListener {
            val uri = Uri.parse("package:${requireContext().packageName}")
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, uri))
        }
    }

    override fun onResume() {
        super.onResume()
        main.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(refresher)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private fun setTimer(minutes: Int) {
        Prefs.setTimerMinutes(requireContext(), minutes)
        refresh()
    }

    private fun refresh() {
        val ctx = context ?: return

        // System health
        val cpu = SystemInfo.cpuPercent()
        b.cpuValue.text = if (cpu == null) "--" else "$cpu%"
        b.cpuLevel.text = when {
            cpu == null -> "belum terbaca"
            cpu >= 80 -> "tinggi"
            cpu >= 50 -> "sedang"
            else -> "rendah"
        }
        val freqs = SystemInfo.coreFreqsMhz()
        b.cpuCores.text = if (freqs.isEmpty()) {
            "frekuensi core tidak terbaca di HP ini"
        } else {
            freqs.mapIndexed { i, mhz -> "core $i: $mhz MHz" }.joinToString("\n")
        }

        val ram = SystemInfo.ram(ctx)
        b.ramValue.text = "${Formatter.formatFileSize(ctx, ram.used)} dari ${Formatter.formatFileSize(ctx, ram.total)}"
        val disk = SystemInfo.storage()
        b.storageValue.text = "${Formatter.formatFileSize(ctx, disk.used)} dari ${Formatter.formatFileSize(ctx, disk.total)}"
        val temp = "%.1f".format(Device.batteryTempC(ctx))
        b.batteryValue.text = "${SystemInfo.batteryPercent(ctx)}%, suhu $temp °C"
        b.deviceValue.text = "${Build.MODEL} · Android ${Build.VERSION.RELEASE}"
        b.connValue.text = if (Device.isInstalled(ctx, SHIZUKU_PKG)) "terpasang" else "belum terpasang"

        // Booster
        val boosted = Prefs.isBoosted(ctx)
        b.statusTitle.text = if (boosted) "booster aktif" else "booster siap"
        b.btnToggle.text = if (boosted) "matikan booster" else "mulai booster"
        b.statusValue.text = Prefs.status(ctx)
        b.gameValue.text = Prefs.currentGame(ctx)?.let { Device.labelOf(ctx, it) } ?: "belum ada game"

        val timer = Prefs.timerMinutes(ctx)
        b.timerValue.text = if (timer > 0) "$timer menit" else "tanpa timer"

        val missing = buildList {
            if (!Device.hasUsageAccess(ctx)) add("pemakaian data")
            if (!Device.hasDndAccess(ctx)) add("jangan ganggu")
            if (!Device.canWriteSettings(ctx)) add("ubah layar")
        }
        b.permValue.text = if (missing.isEmpty()) {
            "semua izin sudah siap"
        } else {
            "belum diizinkan: ${missing.joinToString(", ")}"
        }
    }

    companion object {
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }
}
