package com.zenith.nexus

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityBenchmarkBinding
import java.util.concurrent.Executors

class BenchmarkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBenchmarkBinding
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBenchmarkBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBench.setOnClickListener { runBench() }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun runBench() {
        binding.benchValue.text = getString(R.string.bench_running)
        worker.execute {
            val ms = cpuLoopMs()
            val score = if (ms <= 0L) 0L else 100_000L / ms
            main.post {
                binding.benchValue.text = "waktu: $ms ms\nskor: $score (makin besar makin baik)"
            }
        }
    }

    private fun cpuLoopMs(): Long {
        val start = System.nanoTime()
        var x = 0.0
        for (i in 1..15_000_000) {
            x += Math.sqrt(i.toDouble())
        }
        val ms = (System.nanoTime() - start) / 1_000_000L
        return if (x < 0.0) -1L else ms
    }
}
