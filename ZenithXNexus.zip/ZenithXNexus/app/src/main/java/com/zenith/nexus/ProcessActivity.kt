package com.zenith.nexus

import android.app.ActivityManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.zenith.nexus.databinding.ActivityProcessBinding

class ProcessActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProcessBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProcessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.procStatus.text = getString(R.string.proc_status)
        binding.btnKillBg.setOnClickListener { killBackground() }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val am = getSystemService(ActivityManager::class.java)
        val procs = am.runningAppProcesses ?: emptyList()
        binding.procList.removeAllViews()
        procs.sortedBy { it.importance }.forEach { p ->
            val item = layoutInflater.inflate(R.layout.item_session, binding.procList, false)
            item.findViewById<TextView>(R.id.sessionName).text = p.processName
            item.findViewById<TextView>(R.id.sessionDetail).text = importanceText(p.importance)
            binding.procList.addView(item)
        }
    }

    private fun importanceText(importance: Int): String = when {
        importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "sedang dipakai"
        importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "terlihat"
        importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE -> "layanan latar"
        else -> "latar belakang"
    }

    private fun killBackground() {
        val am = getSystemService(ActivityManager::class.java)
        var count = 0
        Device.launchableApps(this).forEach { app ->
            am.killBackgroundProcesses(app.pkg)
            count++
        }
        Toast.makeText(this, "$count aplikasi latar diminta berhenti", Toast.LENGTH_SHORT).show()
        render()
    }
}
