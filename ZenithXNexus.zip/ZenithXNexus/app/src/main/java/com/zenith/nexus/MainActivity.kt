package com.zenith.nexus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.zenith.nexus.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var unlocked = false
    private var notifAsked = false
    private var pendingLaunch: String? = null
    private var pendingExternal: String? = null

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startBooster() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Notifier.createChannels(this)

        binding.btnUnlock.setOnClickListener { authenticate() }
        binding.bottomNav.setOnItemSelectedListener { item ->
            showTab(item.itemId)
            true
        }
        showTab(R.id.nav_home)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Shortcuts.update(this)
    }

    override fun onStart() {
        super.onStart()
        if (!unlocked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        unlocked = false
    }

    /** Shortcut ikon app bisa membawa nama paket game. */
    private fun handleIntent(i: Intent?) {
        val pkg = i?.getStringExtra("launch") ?: return
        pendingExternal = pkg
        if (unlocked) consumeExternal()
    }

    private fun consumeExternal() {
        val pkg = pendingExternal ?: return
        pendingExternal = null
        startBooster(pkg)
    }

    private fun showTab(id: Int) {
        val fragment: Fragment = when (id) {
            R.id.nav_games -> GamesFragment()
            R.id.nav_tools -> ToolsFragment()
            R.id.nav_more -> MoreFragment()
            else -> HomeFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    /** Kunci app: sidik jari atau kunci layar HP. Kalau HP belum punya kunci, app langsung terbuka. */
    private fun authenticate() {
        if (!Prefs.isOn(this, Option.LOCK) || !Device.isDeviceSecure(this)) {
            showContent()
            return
        }

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                showContent()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                showLock()
            }
        }

        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), callback)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Buka Zenith X Nexus")
            .setSubtitle("Pakai sidik jari atau kunci layar HP kamu")

        if (Build.VERSION.SDK_INT >= 30) {
            info.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
        } else {
            info.setDeviceCredentialAllowed(true)
        }
        prompt.authenticate(info.build())
    }

    private fun showContent() {
        unlocked = true
        binding.lockView.visibility = View.GONE
        binding.content.visibility = View.VISIBLE
        consumeExternal()
    }

    private fun showLock() {
        unlocked = false
        binding.content.visibility = View.GONE
        binding.lockView.visibility = View.VISIBLE
    }

    /** Dipanggil dari beranda, menu game, dan shortcut. */
    fun startBooster(launch: String? = null) {
        if (!Device.hasUsageAccess(this)) {
            toast("Izinkan pemakaian data dulu, lalu kembali ke sini")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifAsked = true
            pendingLaunch = launch ?: pendingLaunch
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }

        val free = StorageInfo.freeBytes()
        if (launch != null && free < LOW_STORAGE_BYTES) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.storage_title)
                .setMessage("${getString(R.string.storage_msg)}\nSisa: ${Formatter.formatFileSize(this, free)}")
                .setPositiveButton(R.string.storage_continue) { _, _ -> launchNow(launch) }
                .setNegativeButton(R.string.storage_cancel, null)
                .show()
            return
        }
        launchNow(launch)
    }

    private fun launchNow(launch: String?) {
        ContextCompat.startForegroundService(this, Intent(this, BoostService::class.java))
        val target = launch ?: pendingLaunch
        pendingLaunch = null
        val gameIntent = target?.let { packageManager.getLaunchIntentForPackage(it) }
        if (gameIntent != null) {
            startActivity(gameIntent)
        } else {
            toast("Booster aktif. Silakan buka game kamu.")
        }
    }

    /** Dipanggil dari beranda. */
    fun stopBooster() {
        stopService(Intent(this, BoostService::class.java))
        toast("Booster dimatikan. Setting dikembalikan.")
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val LOW_STORAGE_BYTES = 1_000_000_000L
    }
}
